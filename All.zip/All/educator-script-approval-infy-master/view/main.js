var request = new XMLHttpRequest();

request.open('GET', 'http://localhost:3000/educators', true);
request.onload = function () {

  // Begin accessing JSON data here
  var data = JSON.parse(this.response);
  var root = document.getElementById("cards-new");
    
  console.log(data.count);
  if (request.status >= 200 && request.status < 400) {

    
    for(let i= 0 ; i < data.count ; i ++)
    {
      var html = ""
      html += "<div class='custom-card col-lg-3 m-2 p-0 shadow'>";
      html += "<div class='card-info'><h4>" + data.educators[i].empid + "</h4>";
      html += "<span class='mt-3'><h6 class='pr-2'>" + data.educators[i].title +"</h6></span>";
      html += "<div class='progress'>";
      html += "<div class='progress-bar bg-success' role='progressbar' style='width: 25%' aria-valuenow='15' aria-valuemin='0' aria-valuemax='100'</div>&nbsp>";
      html += "<div class='progress-bar bg-success' role='progressbar' style='width: 25%' aria-valuenow='30' aria-valuemin='0' aria-valuemax='100'</div>&nbsp>";
      html += "<div class='progress-bar bg-success' role='progressbar' style='width: 25%' aria-valuenow='20' aria-valuemin='0' aria-valuemax='100'</div>&nbsp>";
      html += "<div class='progress-bar bg-success' role='progressbar' style='width: 25%' aria-valuenow='0' aria-valuemin='0' aria-valuemax='100'</div>&nbsp>";
      html += "</div><div class='card-meta'> <p class='m-0'>" + data.educators[i].preprodstatus + "</p>";
    
      html += "</div></div>";
      root.innerHTML += html;
    }

    

  } else {
    console.log("error");
  }
}
request.send();